"""Mock radar reader for development without physical hardware."""

from __future__ import annotations

from datetime import datetime, timedelta
import math
from typing import Literal

from .radar_model import RadarFrame, RadarPoint

MockScenario = Literal["empty", "normal", "fall-demo", "presence-demo"]
MockRadarStatus = Literal["NORMAL", "WARNING", "FALL"]
MOCK_SCENARIOS: tuple[MockScenario, ...] = (
    "empty",
    "normal",
    "fall-demo",
    "presence-demo",
)


class MockRadarReader:
    """Generate deterministic LD6002C-like normalized frames.

    Scenarios use one frame per simulated second:
    - empty: no human present, no fall alarm.
    - normal: human present, no fall alarm.
    - fall-demo:
    - 0 to 10 seconds: human present, no fall.
    - 10 to 16 seconds: fall detected.
    - after 16 seconds: human present, no fall.
    - presence-demo: cycles between empty room and normal human presence.
    """

    def __init__(
        self,
        start_time: datetime | None = None,
        interval_seconds: float = 1.0,
        scenario: MockScenario = "empty",
    ) -> None:
        if interval_seconds <= 0:
            raise ValueError("interval_seconds must be greater than 0")
        if scenario not in MOCK_SCENARIOS:
            choices = ", ".join(MOCK_SCENARIOS)
            raise ValueError(f"scenario must be one of: {choices}")

        self.start_time = start_time or datetime.now()
        self.interval_seconds = interval_seconds
        self.scenario = scenario
        self._frame_index = 0

    def read(self) -> RadarFrame:
        """Return the next simulated radar frame."""

        elapsed_seconds = self._frame_index * self.interval_seconds
        timestamp = self.start_time + timedelta(seconds=elapsed_seconds)
        human_present, fall_detected, motion_state = self._state_for_elapsed(
            elapsed_seconds
        )
        points = self._points_for_elapsed(
            elapsed_seconds,
            human_present=human_present,
            fall_detected=fall_detected,
        )

        frame = RadarFrame(
            timestamp=timestamp,
            human_present=human_present,
            fall_detected=fall_detected,
            motion_state=motion_state,
            raw=(
                f"mock:scenario={self.scenario};index={self._frame_index};"
                f"elapsed={elapsed_seconds:.1f}"
            ),
            points=points,
        )
        self._frame_index += 1
        return frame

    def _state_for_elapsed(self, elapsed_seconds: float) -> tuple[bool, bool, str]:
        if self.scenario == "empty":
            return False, False, "none"

        if self.scenario == "normal":
            return True, False, "moving"

        if self.scenario == "fall-demo":
            fall_detected = 10 <= elapsed_seconds < 16
            return True, fall_detected, "still" if fall_detected else "moving"

        if self.scenario == "presence-demo":
            cycle_second = int(elapsed_seconds) % 24
            human_present = 6 <= cycle_second < 18
            return human_present, False, "moving" if human_present else "none"

        raise RuntimeError(f"unsupported mock scenario: {self.scenario}")

    @staticmethod
    def _points_for_elapsed(
        elapsed_seconds: float,
        *,
        human_present: bool,
        fall_detected: bool,
    ) -> tuple[RadarPoint, ...]:
        """Build a deterministic teaching trajectory, clearly marked as mock."""

        if not human_present:
            return ()

        status: MockRadarStatus = "FALL" if fall_detected else "NORMAL"
        return _points_for_status(status, elapsed_seconds)


def build_mock_radar_frame(
    status: MockRadarStatus,
    elapsed_seconds: float,
    *,
    timestamp: datetime | None = None,
    resident_id: str = "demo",
) -> RadarFrame:
    """Build one deterministic community-demo frame from the existing mock model."""

    if status not in {"NORMAL", "WARNING", "FALL"}:
        raise ValueError("status must be NORMAL, WARNING, or FALL")
    if elapsed_seconds < 0:
        raise ValueError("elapsed_seconds must be non-negative")

    fall_detected = status in {"WARNING", "FALL"}
    motion_state = {
        "NORMAL": "moving",
        "WARNING": "unstable",
        "FALL": "still",
    }[status]
    return RadarFrame(
        timestamp=timestamp or datetime.now().astimezone(),
        human_present=True,
        fall_detected=fall_detected,
        motion_state=motion_state,
        raw=(
            f"community-demo:resident={resident_id};status={status};"
            f"elapsed={elapsed_seconds:.2f}"
        ),
        points=_points_for_status(status, elapsed_seconds),
    )


def _points_for_status(
    status: MockRadarStatus,
    elapsed_seconds: float,
) -> tuple[RadarPoint, ...]:
    center_x = 0.28 * math.sin(elapsed_seconds * 0.35)
    center_y = 1.25 + 0.10 * math.cos(elapsed_seconds * 0.25)
    if status == "FALL":
        x_offsets = (-0.72, -0.48, -0.24, 0.0, 0.24, 0.48, 0.72)
        z_values = (0.28, 0.30, 0.32, 0.34, 0.32, 0.30, 0.28)
        speed = 0.02
    elif status == "WARNING":
        x_offsets = (-0.32, -0.20, -0.10, 0.0, 0.12, 0.24, 0.34)
        z_values = (0.52, 0.65, 0.75, 0.85, 0.95, 1.05, 1.12)
        speed = 0.08
    else:
        x_offsets = (-0.06, 0.04, -0.05, 0.05, -0.04, 0.03, 0.0)
        z_values = (0.28, 0.52, 0.78, 1.04, 1.30, 1.55, 1.76)
        speed = 0.18

    return tuple(
        RadarPoint(
            cluster_id=1,
            x=center_x + x_offset,
            y=center_y + 0.025 * math.sin(index + elapsed_seconds * 0.2),
            z=z,
            speed=speed,
        )
        for index, (x_offset, z) in enumerate(zip(x_offsets, z_values, strict=True))
    )
